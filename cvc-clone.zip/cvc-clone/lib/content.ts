const CDN = "https://images.squarespace-cdn.com/content/v1/670423e106da6c036366fd10";

export const site = {
  name: "Conejo Valley Family Counseling",
  logo: `${CDN}/7116bf54-a0e1-4128-81d8-24fd9960c7ed/Conejo+Valley+Counseling+Logo.png?format=1500w`,
  address: ["925 Broadbeck Dr", "Suites 200 and 225", "Newbury Park, CA 91320"],
  email: "info@conejovalleycounseling.com",
  phone: "805.242.3120",
  phoneHref: "tel:8052423120",
  serving: "Serving Thousand Oaks, Westlake Village, Camarillo, Moorpark, & Simi Valley",
};

export const images = {
  hero1: `${CDN}/80513bd1-30ee-4a2d-aaf6-782d9be095ce/Jennifer+A+-+Images+%2866%29.jpg`,
  hero2: `${CDN}/3643a7ac-ff62-4927-b96e-9e65ecff0521/Jennifer+A+-+Images+%2867%29.jpg`,
  beach: `${CDN}/7a40691c-70a5-4307-b9ae-974592087a8f/Jennifer+A+-+Images+%283%29.jpg`,
  adults: `${CDN}/066f60e6-1354-4d47-a586-ab3f2f2ba612/Jennifer+A+-+Images+%288%29.jpg`,
  couples: `${CDN}/d0157712-388c-4800-aada-c78db97ee966/Jennifer+A+-+Images+%289%29.jpg`,
  children: `${CDN}/d5d62bf4-34a7-4bf4-bf00-e1169863ace7/Jennifer+A+-+Images+%2810%29.jpg`,
  banner: `${CDN}/27b4f80c-ca73-4d1f-824e-ec29a2211142/Jennifer+A+-+Images+%282%29.png`,
  how: `${CDN}/389808ad-7273-4e03-a32b-c172aa735f12/Jennifer+A+-+Images+%286%29.jpg`,
  family: `${CDN}/6f1501bf-74a5-4c57-a957-8ce4c5876848/Jennifer+A+-+Images+%285%29.jpg`,
  shells: `${CDN}/1b9495e0-ce39-4826-9df9-e24de99da82f/Jennifer+A+-+Images+%2812%29.jpg`,
  schedule: `${CDN}/7557312a-044d-4489-a9d1-6f43ee9888b1/Jennifer+A+-+Images+%2811%29.jpg`,
};

export const nav = {
  about: { label: "About", href: "#how-we-work" },
  team: [
    "Jennifer Anderson, LMFT", "Candace Bletscher, AMFT", "Heather Williams-Baumgart, AMFT",
    "Samantha Johnson, AMFT", "Autumn Bodily, AMFT", "Rosa Gomez, AMFT", "Chad Flores, AMFT",
    "Simran Sidhu, AMFT", "Jessica Jauregui, MA, AMFT",
  ],
  specialties: ["Dissociation", "Trauma", "Special Needs Parenting", "Couples", "Children & Teens", "Anxiety & Depression", "Adoption"],
  methods: ["EMDR", "Brainspotting", "Somatic Therapy", "Parts Work Therapy"],
};

export const whoWeHelp = [
  { title: "Adults", img: images.adults, alt: "Two people sitting on a log at the beach, facing a lake with mountains in the background.",
    text: "Feeling stuck or overwhelmed? We help adults find clarity, build resilience, and move forward with confidence by addressing the root causes of anxiety, stress, and emotional pain." },
  { title: "Couples", img: images.couples, alt: "A couple embracing on the beach.",
    text: "Relationships require effort, and we’re here to help you strengthen yours. We guide couples through challenges like communication breakdowns and trust issues, helping you rebuild intimacy and strengthen your relationship." },
  { title: "Children & Teens", img: images.children, alt: "A boy carrying a girl on a beach with waves in the background.",
    text: "Kids need support, too. We help them process big emotions, cope with challenging family situations, build coping skills, and feel understood, while also working closely with their parents to create a nurturing environment." },
];

export const expertise = [
  "Dissociation", "Trauma", "Family conflict", "Special needs parenting", "Depression",
  "marriage", "anxiety", "relationships", "children", "teens", "intimacy & connection",
];

export const specialties = [
  { title: "Trauma", text: "We don’t always know when and how we’ve experienced trauma. In therapy, we’ll work together to help you process your past, understand what’s causing you to stay “stuck,” and regain a sense of safety, control, and hope. You don’t have to carry your burdens alone." },
  { title: "Dissociation", text: "The feeling of losing time, hearing conflicting voices, or questioning your sense of self can be overwhelming. In therapy, we’ll help you understand these experiences, recognize your own triggers, and create a sense of balance and identity so that you can feel more grounded." },
  { title: "EMDR", text: "Eye Movement Desensitization and Reprocessing (EMDR) is a powerful therapeutic technique that helps process and heal trauma by reworking how painful memories are stored in your brain. This allows you to find relief and move toward lasting healing." },
  { title: "Special Needs Parenting", text: "Parenting a child with special needs presents unique challenges and complex emotions. We provide compassionate support through lived experience and expertise to help you navigate this journey with tools, understanding, and self-care." },
];
