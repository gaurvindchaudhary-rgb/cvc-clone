import { images } from "@/lib/content";

export default function HowWeWork() {
  return (
    <section id="how-we-work" className="section bg-surface">
      <div className="container-page grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={images.how} alt="A woman and a child in white dresses dancing on a sandy beach at sunset." className="aspect-[4/5] w-full object-cover" />
        <div>
          <p className="eyebrow">HOW WE WORK</p>
          <h2>We’re here to make a difference.</h2>
          <p className="mt-6 font-heading text-2xl italic text-accent">
            The clients we work with are balancing so many things at once, it’s often hard for them to put themselves first.
          </p>
          <p className="mt-6">
            Here, your needs are always top priority. Our team takes the time to deeply listen to our clients in order to truly understand their story and their struggles. We recognize that no two people are the same and that personalized therapy means an intentional, tailored approach. (You won’t find anything “one-size-fits-all” here.) If you’re ready to do the work, we’re ready to help.
          </p>
          <p className="mt-4">
            Sometimes we may gently challenge you to look at things differently and other times we may explore your emotions, all while encouraging you to practice what you’ve learned in your daily life. We take what we do seriously because we know how important it is for you to heal from what’s hurting you, discover a fulfilling life, and build meaningful relationships. Our goal is to walk alongside you in this journey, offering support and guidance as you uncover your strengths and embrace what the future can hold for you.
          </p>
          <a href="#" className="btn-outline mt-8">Learn more about us</a>
        </div>
      </div>
    </section>
  );
}
