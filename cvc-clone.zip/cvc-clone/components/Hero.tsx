import { images } from "@/lib/content";

export default function Hero() {
  return (
    <section className="section bg-surface pt-10 sm:pt-14 lg:pt-16">
      <div className="container-page grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <div>
          <p className="eyebrow italic normal-case tracking-[0.12em]">ONLINE &amp; IN-PERSON COUNSELING IN NEWBURY PARK &amp; ACROSS CA</p>
          <h1>
            Rebuild your foundation on solid ground and finally begin to <em>thrive</em>.
          </h1>
          <p className="mt-6 max-w-md text-lg">
            Specialized therapy for adults, couples, teens, and children to reflect, heal, and grow.
          </p>
          <a href="#schedule" className="btn mt-8">Book an Appointment</a>
        </div>

        <div className="relative mx-auto grid w-full max-w-xl grid-cols-2 gap-4 sm:gap-6">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={images.hero1} alt="family therapy" className="aspect-[3/4] w-full object-cover" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={images.hero2} alt="child therapy" className="mt-12 aspect-[3/4] w-full object-cover sm:mt-16" />
        </div>
      </div>
    </section>
  );
}
