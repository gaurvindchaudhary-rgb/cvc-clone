import { images } from "@/lib/content";

export default function Schedule() {
  return (
    <section id="schedule" className="section bg-surface">
      <div className="container-page grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
        <div>
          <p className="eyebrow">SCHEDULE AN APPOINTMENT</p>
          <h2>
            Find a therapist who is the right fit for <em>you</em>.
          </h2>
          <p className="mt-6">
            Coming to therapy is a courageous decision, and connecting with the right kind of therapist makes all the difference. We understand that your journey is personal, and we&apos;re here to support you with care and understanding every step of the way. Each member of our team brings dedicated expertise and a commitment to support you in your struggles. We want you to feel prioritized, understood, and empowered.
          </p>
          <p className="mt-4">Click the button below to schedule an appointment.</p>
          <a href="#" className="btn mt-8">Book now</a>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:gap-6">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={images.shells} alt="A person picking up seashells on a sandy beach." className="aspect-[3/4] w-full object-cover" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={images.schedule} alt="A person in a striped dress pointing at shells on the sandy beach, with a child nearby." className="mt-10 aspect-[3/4] w-full object-cover" />
        </div>
      </div>
    </section>
  );
}
