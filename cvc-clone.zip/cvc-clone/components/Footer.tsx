import { nav, site } from "@/lib/content";

export default function Footer() {
  const team = nav.team.map((t) => t.split(",")[0]);
  return (
    <footer className="bg-primary px-6 py-14 text-surface sm:px-10 lg:py-20">
      <div className="mx-auto max-w-page">
        <p className="max-w-2xl font-heading text-2xl italic text-surface sm:text-3xl">
          We want to make getting started simple. You’re welcome to come into our office in Newbury Park or schedule virtual appointments from anywhere in CA—whatever works best for you.
        </p>

        <div className="mt-12 grid gap-10 border-t border-surface/30 pt-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h5 className="mb-4 text-xs font-medium uppercase tracking-[0.18em]">Navigate</h5>
            <ul className="space-y-2 text-sm">
              <li><a href="/">Home</a></li>
              <li><a href="#how-we-work">About</a></li>
              <li><a href="#">FAQs</a></li>
              <li><a href="#schedule">Contact</a></li>
            </ul>
          </div>
          <div>
            <h5 className="mb-4 text-xs font-medium uppercase tracking-[0.18em]">Contact</h5>
            <address className="space-y-1 text-sm not-italic">
              {site.address.map((l) => <div key={l}>{l}</div>)}
              <div className="pt-2"><a href={`mailto:${site.email}`}>{site.email}</a></div>
              <div><a href={site.phoneHref}>{site.phone}</a></div>
            </address>
            <p className="mt-4 text-xs italic !leading-relaxed text-surface/80">{site.serving}</p>
          </div>
          <div className="sm:col-span-2">
            <h5 className="mb-4 text-xs font-medium uppercase tracking-[0.18em]">Our Team</h5>
            <ul className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
              {team.map((t) => <li key={t}><a href="#">{t}</a></li>)}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-surface/30 pt-6 text-xs text-surface/80 sm:flex-row sm:justify-between">
          <p className="!text-xs">
            <a href="#">Terms</a> | <a href="#">Privacy Policy</a> | <a href="#">Disclaimer</a>
          </p>
          <p className="!text-xs">© Conejo Valley Family Counseling</p>
        </div>
      </div>
    </footer>
  );
}
