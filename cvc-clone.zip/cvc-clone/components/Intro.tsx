import { images } from "@/lib/content";

export default function Intro() {
  return (
    <section className="section bg-surface-alt">
      <div className="container-page grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
        <div>
          <h2>You’re holding onto hope that life can be better than it is right now.</h2>
          <p className="mt-6 font-heading text-2xl italic text-accent">
            At Conejo Valley Family Counseling we want to make that hope a reality.
          </p>
          <p className="mt-6">
            Whether you&apos;re an adult seeking personal growth, looking to work through your trauma, a couple working on your relationship, or a parent looking for support for your child, we provide a compassionate and safe space to help you navigate all of life’s ups and downs.
          </p>
          <p className="mt-4">
            First and foremost, we believe what you’re going through is real, valid, and worthy of support. Our team offers clients in the Newbury Park area and across CA an environment to discover a new life and a deeper sense of self in the midst of their struggles. As we tap into the power of connection and understanding, you can find your footing again and take a transformative path forward.
          </p>
        </div>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={images.beach} alt="Sandy beach with gentle ocean waves and a cloudy sky." className="aspect-[4/5] w-full object-cover lg:order-first" />
      </div>
    </section>
  );
}
